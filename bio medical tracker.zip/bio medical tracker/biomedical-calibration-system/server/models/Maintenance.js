const mongoose = require('mongoose');

const maintenanceSchema = new mongoose.Schema(
  {
    workOrderId: {
      type: String,
      required: [true, 'Work order ID is required (e.g. WO-2026-001)'],
      unique: true,
      trim: true,
      uppercase: true,
      index: true
    },
    equipment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Equipment',
      required: [true, 'Associated equipment reference is required'],
      index: true
    },
    maintenanceType: {
      type: String,
      required: [true, 'Maintenance classification type is required'],
      enum: {
        values: ['Preventive', 'Corrective', 'Emergency Breakdown'],
        message: '{VALUE} is not a valid maintenance type'
      },
      default: 'Preventive',
      index: true
    },
    issueDescription: {
      type: String,
      required: [true, 'Issue description is required'],
      trim: true
    },
    reportedDate: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      required: [true, 'Maintenance status is required'],
      enum: {
        values: ['Reported', 'Assigned', 'In Progress', 'Resolved', 'Closed'],
        message: '{VALUE} is not a valid work order status'
      },
      default: 'Reported',
      index: true
    },
    priority: {
      type: String,
      required: [true, 'Priority level is required'],
      enum: {
        values: ['Low', 'Medium', 'High', 'Critical'],
        message: '{VALUE} is not a valid priority level'
      },
      default: 'Medium',
      index: true
    },
    actionTaken: {
      type: String,
      trim: true,
      default: 'Pending inspection'
    },
    reportedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null
    },
    assignedTo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null
    }
  },
  {
    timestamps: true
  }
);

// Compound index for querying active maintenance work orders for an equipment
maintenanceSchema.index({ equipment: 1, status: 1 });

module.exports = mongoose.model('Maintenance', maintenanceSchema);
