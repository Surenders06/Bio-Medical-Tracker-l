const mongoose = require('mongoose');

const equipmentSchema = new mongoose.Schema(
  {
    equipmentId: {
      type: String,
      required: [true, 'Equipment ID is required (e.g. BMD-ECG-101)'],
      unique: true,
      trim: true,
      uppercase: true,
      index: true
    },
    name: {
      type: String,
      required: [true, 'Equipment name is required'],
      trim: true
    },
    category: {
      type: String,
      required: [true, 'Equipment category is required'],
      enum: {
        values: [
          'Diagnostic',
          'Life Support',
          'Monitoring',
          'Laboratory',
          'Therapeutic',
          'Surgical'
        ],
        message: '{VALUE} is not a valid equipment category'
      },
      index: true
    },
    manufacturer: {
      type: String,
      required: [true, 'Manufacturer name is required'],
      trim: true
    },
    model: {
      type: String,
      required: [true, 'Model name or number is required'],
      trim: true
    },
    serialNumber: {
      type: String,
      trim: true,
      default: 'N/A'
    },
    location: {
      department: {
        type: String,
        required: [true, 'Clinical department is required'],
        trim: true
      },
      roomNumber: {
        type: String,
        trim: true,
        default: 'General'
      },
      building: {
        type: String,
        trim: true,
        default: 'Main Block'
      }
    },
    purchaseDate: {
      type: Date,
      default: Date.now
    },
    purchaseCost: {
      type: Number,
      min: [0, 'Purchase cost must be a non-negative number'],
      default: 0
    },
    status: {
      type: String,
      enum: {
        values: [
          'Operational',
          'Maintenance Required',
          'Calibration Due',
          'Out of Service'
        ],
        message: '{VALUE} is not a valid equipment status'
      },
      default: 'Operational',
      index: true
    },
    calibrationFrequencyMonths: {
      type: Number,
      required: [true, 'Calibration frequency in months is required'],
      min: [1, 'Calibration frequency must be at least 1 month'],
      default: 6
    },
    lastCalibrationDate: {
      type: Date,
      default: null
    },
    nextCalibrationDate: {
      type: Date,
      default: null,
      index: true
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Creator user reference is required']
    }
  },
  {
    timestamps: true
  }
);

// Compound index for category and status filtering
equipmentSchema.index({ category: 1, status: 1 });
equipmentSchema.index({ name: 'text', manufacturer: 'text', model: 'text' });

module.exports = mongoose.model('Equipment', equipmentSchema);
