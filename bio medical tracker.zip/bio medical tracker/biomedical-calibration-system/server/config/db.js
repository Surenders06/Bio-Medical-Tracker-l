const mongoose = require('mongoose');

/**
 * Establish connection to MongoDB using Mongoose
 * Reads MONGODB_URI from environment variables
 */
const connectDB = async () => {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/biomedical_calibration_db';
    const conn = await mongoose.connect(mongoUri);

    console.log(`[MongoDB Connected] Host: ${conn.connection.host} | DB: ${conn.connection.name}`);
    return conn;
  } catch (error) {
    console.error(`[MongoDB Connection Error] ${error.message}`);
    // Return null so the server can run and return structured status without crashing unhandled
    return null;
  }
};

module.exports = connectDB;
