# REST API Specification: Biomedical Device Calibration and Maintenance Management System

## 1. API Architecture Overview
* **Base URL**: `http://localhost:5000/api`
* **Protocol**: HTTP/1.1 RESTful JSON API
* **Content-Type**: `application/json; charset=utf-8`
* **Authentication**: Stateless JSON Web Token (JWT)
  * Format: `Authorization: Bearer <JWT_TOKEN>`
  * Header validation executed via `authMiddleware.js`
* **Authorization**: Role-Based Access Control executed via `roleMiddleware.js`

---

## 2. Standard Response Envelopes

### 2.1. Success Response Structure
```json
{
  "success": true,
  "message": "Operation completed successfully",
  "data": { ... }
}
```

### 2.2. Error Response Structure
```json
{
  "success": false,
  "message": "Human-readable error explanation",
  "error": "Detailed validation or system error message"
}
```

---

## 3. Endpoints Documentation

### 3.1. Authentication & User Management Module (`/api/auth`)

#### `POST /api/auth/login`
Authenticates user credentials and returns a JWT access token.
* **Access**: Public
* **Request Body**:
  ```json
  {
    "email": "admin@biomed.hospital.org",
    "password": "Admin@123"
  }
  ```
* **Success Response (200 OK)**:
  ```json
  {
    "success": true,
    "message": "Authentication successful",
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": "66fa...",
      "name": "Dr. Rajesh Sharma",
      "email": "admin@biomed.hospital.org",
      "role": "Admin",
      "department": "Biomedical Engineering"
    }
  }
  ```
* **Error Responses**: `400 Bad Request` (missing fields), `401 Unauthorized` (invalid password or email not found).

---

#### `POST /api/auth/register`
Creates a new user account.
* **Access**: Public (Initial Setup) / Admin Only (In production)
* **Request Body**:
  ```json
  {
    "name": "Priya Raman",
    "email": "tech.priya@biomed.hospital.org",
    "password": "Tech@123",
    "role": "Technician",
    "department": "Clinical Calibration Services"
  }
  ```
* **Success Response (201 Created)**: User created with JWT token.
* **Error Responses**: `400 Bad Request` (email already exists or missing fields).

---

#### `GET /api/auth/me`
Fetches the currently authenticated user's profile from the JWT token.
* **Access**: Private (Admin, Technician, Staff)
* **Headers**: `Authorization: Bearer <token>`
* **Success Response (200 OK)**: Returns user object without password hash.

---

#### `GET /api/auth/users`
Lists all registered users in the hospital system.
* **Access**: Private (Admin only)
* **Headers**: `Authorization: Bearer <token>`
* **Success Response (200 OK)**:
  ```json
  {
    "success": true,
    "count": 3,
    "users": [ ... ]
  }
  ```
* **Error Responses**: `403 Forbidden` (if accessed by non-Admin).

---

### 3.2. Biomedical Equipment Management Module (`/api/equipment`)

#### `GET /api/equipment`
Retrieves equipment records with multi-criteria filtering and keyword search.
* **Access**: Private (Admin, Technician, Staff)
* **Query Parameters**:
  * `search` (optional): Matches substring in `name`, `equipmentId`, `manufacturer`, `model`.
  * `category` (optional): Filter by enum value (`Diagnostic`, `Life Support`, `Monitoring`, etc.).
  * `status` (optional): Filter by operational status (`Operational`, `Calibration Due`, `Maintenance Required`, `Out of Service`).
* **Success Response (200 OK)**:
  ```json
  {
    "success": true,
    "count": 8,
    "data": [
      {
        "_id": "66fa...",
        "equipmentId": "BMD-ECG-101",
        "name": "12-Lead Diagnostic ECG Machine",
        "category": "Diagnostic",
        "manufacturer": "GE Healthcare",
        "model": "MAC 2000",
        "serialNumber": "GE-MAC-98231",
        "location": {
          "department": "Cardiology ICU",
          "roomNumber": "ICU-Bed 04",
          "building": "Block A - Critical Care"
        },
        "status": "Operational",
        "calibrationFrequencyMonths": 6,
        "lastCalibrationDate": "2026-08-15T00:00:00.000Z",
        "nextCalibrationDate": "2027-02-15T00:00:00.000Z"
      }
    ]
  }
  ```

---

#### `GET /api/equipment/:id`
Retrieves full details of a specific device along with its historical calibration logs.
* **Access**: Private (Admin, Technician, Staff)
* **Success Response (200 OK)**: Returns equipment document populated with `createdBy` and array of `calibrations`.
* **Error Responses**: `404 Not Found`.

---

#### `POST /api/equipment`
Adds a new biomedical device to the database.
* **Access**: Private (Admin, Technician)
* **Request Body**:
  ```json
  {
    "equipmentId": "BMD-DEF-501",
    "name": "Biphasic Defibrillator & Monitor",
    "category": "Life Support",
    "manufacturer": "ZOLL Medical",
    "model": "R Series ALS",
    "serialNumber": "ZL-RS-33810",
    "location": {
      "department": "Operation Theater",
      "roomNumber": "OT Suite 3",
      "building": "Surgical Wing"
    },
    "purchaseDate": "2025-01-10",
    "purchaseCost": 950000,
    "status": "Operational",
    "calibrationFrequencyMonths": 6
  }
  ```
* **Success Response (201 Created)**: Returns created equipment.
* **Error Responses**: `400 Bad Request` (duplicate equipmentId or missing required fields), `403 Forbidden` (Staff role).

---

#### `PUT /api/equipment/:id`
Updates equipment metadata, department location, or operational status.
* **Access**: Private (Admin, Technician)
* **Success Response (200 OK)**: Returns updated equipment document.
* **Error Responses**: `404 Not Found`, `403 Forbidden`.

---

#### `DELETE /api/equipment/:id`
Removes an equipment item and its cascading calibration history.
* **Access**: Private (Admin only)
* **Success Response (200 OK)**:
  ```json
  {
    "success": true,
    "message": "Equipment 'BMD-ECG-101' and its associated records removed."
  }
  ```
* **Error Responses**: `403 Forbidden` (Technicians and Staff cannot delete records).

---

### 3.3. Calibration Management Module (`/api/calibrations`)

#### `GET /api/calibrations`
Retrieves all calibration records, optionally filtered by equipment ID or test outcome.
* **Access**: Private (Admin, Technician, Staff)
* **Query Parameters**:
  * `equipmentId` (optional): Filter logs for a specific device.
  * `result` (optional): Filter by `Passed`, `Failed`, `Needs Attention`.
* **Success Response (200 OK)**: Returns array of calibrations populated with equipment details and technician info.

---

#### `GET /api/calibrations/:id`
Retrieves a single calibration record by its ID.
* **Access**: Private (Admin, Technician, Staff)
* **Success Response (200 OK)**: Single calibration log with detailed tested parameters.

---

#### `POST /api/calibrations`
Logs a newly performed calibration test and automatically updates equipment dates and operational status.
* **Access**: Private (Admin, Technician)
* **Request Body**:
  ```json
  {
    "calibrationId": "CAL-2026-009",
    "equipmentId": "66fa...",
    "calibrationDate": "2026-09-29",
    "nextCalibrationDate": "2027-03-29",
    "calibrationStandard": "Fluke Biomedical ProSim 8 Vital Signs Simulator",
    "result": "Passed",
    "parametersChecked": [
      {
        "parameter": "Heart Rate Accuracy (60 BPM)",
        "referenceValue": "60 BPM",
        "measuredValue": "60.0 BPM",
        "status": "Pass"
      },
      {
        "parameter": "ECG Amplitude (1.0 mV)",
        "referenceValue": "1.0 mV",
        "measuredValue": "0.99 mV",
        "status": "Pass"
      }
    ],
    "remarks": "Standard test sequence completed. Device within 1% allowable clinical tolerance."
  }
  ```
* **Success Response (201 Created)**: Returns created calibration log and updates parent equipment record.
* **Error Responses**: `400 Bad Request` (missing mandatory test fields), `404 Not Found` (equipment ID invalid).

---

### 3.4. Maintenance Management Module (`/api/maintenance`)

#### `GET /api/maintenance`
Fetches maintenance work order tickets.
* **Access**: Private (Admin, Technician, Staff)

#### `POST /api/maintenance`
Logs a new defect or repair ticket.
* **Access**: Private (Admin, Technician, Staff)

#### `PUT /api/maintenance/:id`
Updates ticket status (e.g., from `Reported` to `In Progress` or `Resolved`).
* **Access**: Private (Admin, Technician)

---

### 3.5. Dashboard & Analytics Module (`/api/dashboard`)

#### `GET /api/dashboard/summary`
Calculates real-time metrics and aggregations directly from MongoDB collections.
* **Access**: Private (Admin, Technician, Staff)
* **Success Response (200 OK)**:
  ```json
  {
    "success": true,
    "developmentStage": "Approximately 50% Prototype",
    "metrics": {
      "totalEquipment": 8,
      "statusCounts": {
        "operational": 5,
        "calibrationDue": 1,
        "maintenanceRequired": 1,
        "outOfService": 1
      },
      "calibrationCounts": {
        "total": 6,
        "passed": 4,
        "needsAttention": 2
      },
      "maintenanceCounts": {
        "totalWorkOrders": 1
      },
      "categoryBreakdown": [
        { "_id": "Diagnostic", "count": 2 },
        { "_id": "Life Support", "count": 2 },
        { "_id": "Monitoring", "count": 2 }
      ],
      "recentCalibrations": [ ... ],
      "upcomingCalibrations": [ ... ]
    }
  }
  ```

---

### 3.6. System Status & Health Check Endpoints

#### `GET /api/health`
Core backend health verification endpoint created in Phase 1 (Backend Foundation).
* **Access**: Public
* **Status**: **ACTIVE & IMPLEMENTED**
* **Expected Response (200 OK)**:
  ```json
  {
    "success": true,
    "message": "Biomedical Calibration API is running"
  }
  ```

#### `GET /api/status`
System status endpoint confirming development roadmap, active modules, and scope.
* **Access**: Public
* **Success Response (200 OK)**:
  ```json
  {
    "status": "Operational",
    "system": "Biomedical Device Calibration and Maintenance Management System",
    "developmentPhase": "Phase 1 - Backend Foundation Active"
  }
  ```

