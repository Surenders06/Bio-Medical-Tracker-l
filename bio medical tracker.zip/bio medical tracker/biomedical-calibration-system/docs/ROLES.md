# Role-Based Access Control (RBAC): Biomedical Device Calibration and Maintenance Management System

## 1. User Roles Overview

The system strictly supports three distinct user roles tailored to real-world hospital clinical engineering workflows:

1. **ADMIN (Biomedical Department Head / Clinical Engineering Director)**
   * Responsible for overall hospital equipment inventory governance, user account management, equipment addition/editing/deletion, and regulatory audit compliance oversight.
2. **TECHNICIAN (Biomedical Service Engineer / Calibration Technician)**
   * Responsible for performing calibration testing against certified standard instruments, logging test parameters, updating equipment operational statuses, and executing maintenance work orders.
3. **STAFF (ICU Nurse In-Charge / OT Technician / Ward Physician / Department Staff)**
   * Clinical front-line users who require immediate verification of medical device calibration validity before clinical application on patients, and who submit maintenance fault reports when equipment malfunctions.

---

## 2. Role Permissions Matrix

| Feature / Action | Admin | Technician | Staff / User | Enforced Layer |
|---|:---:|:---:|:---:|---|
| **User Authentication (Login / Logout)** | ✅ | ✅ | ✅ | Backend JWT & React Context |
| **View Dashboard Summary** | ✅ | ✅ | ✅ | Express API & React UI |
| **View Equipment Inventory List** | ✅ | ✅ | ✅ | Express API & React UI |
| **Search & Filter Equipment** | ✅ | ✅ | ✅ | Express API & React UI |
| **View Detailed Equipment Specs** | ✅ | ✅ | ✅ | Express API & React UI |
| **Add New Biomedical Device** | ✅ | ✅ | ❌ | Backend `roleMiddleware` (`Admin`, `Technician`) |
| **Edit Equipment Information** | ✅ | ✅ | ❌ | Backend `roleMiddleware` (`Admin`, `Technician`) |
| **Delete Biomedical Device** | ✅ | ❌ | ❌ | Backend `roleMiddleware` (`Admin` only) |
| **View Calibration Records** | ✅ | ✅ | ✅ | Express API & React UI |
| **Add / Log New Calibration Record** | ✅ | ✅ | ❌ | Backend `roleMiddleware` (`Admin`, `Technician`) |
| **View Maintenance Work Orders** | ✅ | ✅ | ✅ | Express API & React UI |
| **Submit Maintenance Fault Report** | ✅ | ✅ | ✅ | Express API & React UI |
| **Update / Resolve Maintenance Ticket** | ✅ | ✅ | ❌ | Backend `roleMiddleware` (`Admin`, `Technician`) |
| **Manage Users & View User Directory** | ✅ | ❌ | ❌ | Backend `roleMiddleware` (`Admin` only) |
| **Print Calibration Reports (Browser Print)**| ✅ | ✅ | ✅ | Client CSS Print Stylesheet |

---

## 3. Detailed Role Workflow Scenarios

### 3.1. Admin Workflow Scenario
1. **Login**: Authenticates via `admin@biomed.hospital.org`.
2. **Inventory Governance**: Registers new hospital acquisitions (e.g., newly arrived ICU ventilators or ultrasound scanners). Sets calibration frequency (e.g., 3 months, 6 months).
3. **Decommissioning**: When an obsolete device reaches end-of-life or fails irreparably, Admin possesses sole authority to permanently retire or delete the asset from active service.
4. **Audit Readiness**: Inspects dashboard compliance metrics and reviews department-wide calibration compliance status.

### 3.2. Technician Workflow Scenario
1. **Login**: Authenticates via `tech.priya@biomed.hospital.org`.
2. **Daily Inspection**: Reviews the dashboard for devices flagged with status `Calibration Due` or upcoming due within 15 days.
3. **Field Calibration Execution**:
   * Inspects the target device in the clinical department using a certified standard instrument (e.g., Fluke Biomedical ProSim 8).
   * Navigates to the Calibration module and logs the calibration certificate number, test date, and next calculated due date.
   * Inputs measured values against reference values (e.g., Heart Rate accuracy, Tidal Volume, Flow Rate).
   * Selects test outcome (`Passed`, `Passed with Adjustment`, `Failed`, `Needs Attention`).
4. **Automatic Status Synchronization**: The system immediately synchronizes the device's operational status to `Operational` (if passed) or `Out of Service` (if failed).

### 3.3. Staff / User Workflow Scenario
1. **Login**: Authenticates via `staff.mary@biomed.hospital.org`.
2. **Pre-Patient Verification**: Before attaching a biomedical device (e.g., Defibrillator or Infusion Pump) to an ICU patient, nursing staff quickly searches the device ID.
3. **Safety Verification**: Verifies the green `Operational` badge and confirms the next calibration date has not expired.
4. **Fault Reporting**: If a cable is damaged or an error code appears during clinical use, staff clicks "Report Fault" to create a maintenance ticket for biomedical engineering technicians to attend.

---

## 4. Technical Enforcement Mechanism

### Backend Enforcement (`roleMiddleware.js`):
```javascript
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Forbidden: User role '${req.user?.role}' does not have required permissions.`
      });
    }
    next();
  };
};
```

### Frontend Enforcement:
* **Route Guards (`ProtectedRoute.jsx`)**: Checks if `user.role` matches allowed roles before rendering route elements; redirects unauthorized attempts to `/dashboard`.
* **Conditional UI Controls**: Action buttons (such as "Add Equipment", "Delete", "Add Calibration Log") are conditionally hidden or disabled for `Staff` accounts to prevent unauthorized requests.
