# Engineering Build Log: Biomedical Device Calibration and Maintenance Management System

## Phase 0: Project Initiation, Architecture Blueprint & Documentation

### Date: 2026-09-29
**Milestone**: Project Blueprint Definition & Technical Governance

---

### Architectural Decisions & Rationale

#### ADR 01: Pure MERN Baseline Without External Heavyweight Libraries
* **Context**: Academic B.Tech projects often suffer from dependency bloat (e.g. Redux, Axios, Tailwind, Bootstrap, Recharts, Lucide icons), which obscures core architectural understanding, complicates build pipelines, and violates college review guidelines.
* **Decision**: Strictly reject all external styling frameworks and utility libraries. Utilize vanilla CSS with CSS variables, modern flexbox/grid layout, and native browser `fetch()`. State management will rely strictly on React hooks (`useState`, `useEffect`) and native `createContext` for authentication.
* **Outcome**: Lightweight, zero-dependency frontend bundle, maximum auditability for academic evaluation, and zero external build-step vulnerabilities.

---

#### ADR 02: Node.js Built-In Watch Mode (`node --watch`)
* **Context**: The developer environment requires auto-reloading during server development without installing superfluous global or dev dependencies like `nodemon`.
* **Decision**: Adopt Node.js 18+ native flag: `node --watch server.js`.
* **Outcome**: Eliminated external dependencies while maintaining real-time developer productivity.

---

#### ADR 03: Browser-Native Print Engine for Calibration Reports
* **Context**: In later phases, the application requires printable calibration certificates and equipment maintenance logs. Introducing PDF libraries (e.g. `jspdf`, `pdfmake`, `html2canvas`) bloats client bundles and introduces cross-browser layout inconsistencies.
* **Decision**: Standardize on `window.print()` coupled with dedicated CSS `@media print` rules that hide navigation bars, format clean clinical headers, and fit pages perfectly to standard A4 printing.
* **Outcome**: Clean, zero-dependency reporting suitable for college evaluation.

---

#### ADR 04: Explicit Non-Goals & Ethical Safety Boundaries
* **Context**: The software operates in the healthcare technology domain. Untrained observers or evaluators might misinterpret the software as a hardware calibrator or medical device certification authority.
* **Decision**: Enforce explicit documentation and UI declarations in all specifications:
  1. The software is strictly a **record-management and tracking system**.
  2. The software **never** physically calibrates medical equipment.
  3. The software **never** claims to certify or issue regulatory approvals.
* **Outcome**: Clear academic boundaries, full regulatory compliance, and responsible software engineering principles.

---

#### ADR 05: Explicit 5-Phase Incremental Delivery Plan
* **Context**: To ensure controlled, reviewable engineering without premature feature overbuilding.
* **Decision**: The project is structured into sequential development puzzles:
  * **Phase 0**: Architecture Blueprint & Documentation (Current)
  * **Phase 1**: Backend Data Models, Database Connection & Seeder
  * **Phase 2**: Express REST Controllers, Middleware & Postman Testing Suite
  * **Phase 3**: React Frontend Setup, Context API & Route Structure
  * **Phase 4**: Biomedical Equipment & Calibration Interactive Modules (50% Review Prototype)
  * **Phase 5**: Maintenance Lifecycle, Browser Print Reports & Final Review Hardening
* **Outcome**: Strict phase boundaries preventing accidental feature creep.

---

## Phase 1: Backend Foundation & Mongoose Models

### Date: 2026-09-29
**Milestone**: Express Server & Database Models Foundation

#### 1. Manifest & Dependency Governance (`server/package.json`)
* Configured `package.json` with only approved dependencies: `express`, `mongoose`, `dotenv`, `cors`, `bcryptjs`, `jsonwebtoken`.
* Configured start scripts: `"start": "node server.js"` and `"dev": "node --watch server.js"`.

#### 2. Mongoose Database Connection Module (`server/config/db.js`)
* Configured asynchronous `connectDB` reading `MONGODB_URI` from `.env`.
* Protected against unhandled process crashes on connection errors by returning `null` with clear diagnostic logs.

#### 3. Mongoose Schemas & Models (`server/models/`)
* **`User.js`**: Includes `name`, `email` (unique index), `password` (minlength 6, hidden by default), `role` (`Admin`, `Technician`, `Staff`), `department`. Added `pre('save')` bcrypt hashing hook and `comparePassword` instance method.
* **`Equipment.js`**: Includes `equipmentId` (unique index), `name`, `category`, `manufacturer`, `model`, `serialNumber`, `location` (department, roomNumber, building), `purchaseDate`, `purchaseCost`, `status` (`Operational`, `Maintenance Required`, `Calibration Due`, `Out of Service`), `calibrationFrequencyMonths`, `lastCalibrationDate`, `nextCalibrationDate`, `createdBy` (`ObjectId` ref `User`). Added compound indexes `{ category: 1, status: 1 }` and text indexes.
* **`Calibration.js`**: Associated with `equipment` (`ObjectId` ref `Equipment`) and `calibratedBy` (`ObjectId` ref `User`). Added `parametersChecked` subdocument schema, `result` enum, and compound index `{ equipment: 1, calibrationDate: -1 }`.
* **`Maintenance.js`**: Associated with `equipment` (`ObjectId` ref `Equipment`), `reportedBy`, `assignedTo`. Added `priority` and `status` enums, with compound index `{ equipment: 1, status: 1 }`.
* All models configured with `{ timestamps: true }`.

#### 4. Express Server & Health Verification (`server/server.js`)
* Initialized Express with CORS, JSON body parser, URL-encoded parser, and request logger.
* Created `GET /api/health` returning exact JSON: `{"success": true, "message": "Biomedical Calibration API is running"}`.
* Implemented centralized error handler for duplicate keys (code 11000), CastError (invalid ObjectId), and ValidationError.
* Initialized placeholder folder structure: `controllers/`, `middleware/`, `routes/`, `utils/`, `seed/`.

