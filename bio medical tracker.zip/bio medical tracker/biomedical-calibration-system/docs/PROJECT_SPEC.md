# Project Specification: Biomedical Device Calibration and Maintenance Management System

## 1. Project Title & Academic Overview
* **Project Name**: Biomedical Device Calibration and Maintenance Management System
* **Academic Level**: B.Tech Final Year / Semester Engineering Project
* **Domain**: Biomedical Engineering & Healthcare Information Systems (Full Stack Web Application)

---

## 2. Problem Statement
> *"Hospitals and laboratories must regularly calibrate biomedical devices and maintain maintenance records to comply with regulatory standards."*

In modern healthcare facilities, diagnostic, life-support, and therapeutic biomedical devices require strict periodic calibration and routine preventive maintenance to ensure clinical measurement accuracy and patient safety. However, many hospitals rely on fragmented paper logbooks, manual spreadsheets, or ad-hoc reminders, resulting in missed calibration deadlines, regulatory non-compliance, untracked equipment breakdowns, and potential diagnostic errors.

This project delivers a centralized, web-based digital platform to log, track, and monitor biomedical equipment inventories, calibration schedules, and maintenance histories.

---

## 3. Important Project Definition & Explicit Limitations (Non-Goals)

### What the System IS:
* A **Record Management and Tracking System**.
* A centralized database and monitoring portal for biomedical engineers, clinical technicians, and hospital staff.
* A scheduling and alert mechanism for tracking calibration due dates and maintenance events.

### What the System IS NOT (Mandatory Clarifications):
* **No Physical Calibration**: The software **does NOT** perform physical calibration of medical devices.
* **No Equipment Certification**: The software **does NOT** certify medical equipment or issue legal regulatory certifications.
* **No Sensor/Hardware Integration**: The system does not directly interact with medical hardware, sensors, or serial ports.
* **No Regulatory Agency Replacement**: The software does not replace official accreditation or inspection bodies (such as FDA, NABH, AERB, ISO 13485, or NABL).
* **Strict Ethical Claim**: The software must **never** claim that it physically calibrates or legally certifies any medical device.

---

## 4. Strict Technology Stack Restrictions

To maintain academic rigor, clean software design, and adherence to foundational web development standards, the project strictly uses the following approved stack:

### Frontend:
* **React.js**: Functional components with React Hooks (`useState`, `useEffect`, `useContext`, `useMemo`).
* **Vite**: Ultra-fast build tool and local development server.
* **React Router (v6+)**: Declarative client-side routing and protected route wrappers.
* **Native Browser `fetch()` API**: Used exclusively for HTTP requests to the REST API.
* **Plain Vanilla CSS**: Component-scoped and global CSS stylesheets. No CSS utility frameworks.

### Backend:
* **Node.js**: Runtime environment utilizing modern ES/CommonJS modules and built-in Node watch mode (`node --watch`) instead of nodemon.
* **Express.js**: Lightweight REST API web framework.
* **MongoDB**: NoSQL document database.
* **Mongoose**: Object Data Modeling (ODM) library for schema definitions, validation, and queries.
* **JWT (`jsonwebtoken`)**: Stateless token-based user authentication.
* **bcryptjs**: Salt generation and one-way password hashing.
* **dotenv**: Runtime environment variable configuration.
* **cors**: Cross-Origin Resource Sharing middleware for frontend-backend communication.

### Testing:
* **Postman**: Dedicated API testing suite and JSON collection.

### Reporting Strategy:
* **Native Browser Print (`window.print()`)**: Formatted printable calibration certificates and equipment history sheets styled using CSS `@media print` queries. No heavy PDF generation libraries.

### Explicitly Prohibited Technologies:
* ❌ **Redux / MobX / Zustand**: State management must use React built-in state and Context API.
* ❌ **Axios / Superagent**: All network requests must use the browser's native `fetch()`.
* ❌ **TailwindCSS / Bootstrap / Material-UI / Ant Design**: All UI layout and styling must use plain CSS.
* ❌ **Recharts / Chart.js / D3.js**: No external charting libraries.
* ❌ **Lucide / FontAwesome / Material Icons**: No heavy external icon packages; clean unicode symbols or inline SVG will be used.
* ❌ **Email / SMS Services (Nodemailer, Twilio, SendGrid)**: Out of scope.
* ❌ **Cloud Storage (AWS S3, Firebase, Cloudinary)**: All records are stored directly in MongoDB.
* ❌ **Third-party File Upload Systems (Multer, Busboy)**: Not introduced.
* ❌ **Unnecessary validation or utility libraries (Lodash, Moment.js, Joi, Yup)**: Native JavaScript Date and built-in Mongoose schema validation will be utilized.

---

## 5. Core System Modules

1. **Authentication Module**: Secure login, password hashing via bcryptjs, and stateless JWT token issuance.
2. **User Management Module**: User administration across Admin, Technician, and Staff roles.
3. **Biomedical Equipment Management Module**: Complete CRUD lifecycle for biomedical inventory (device ID, category, manufacturer, model, location, cost, status).
4. **Calibration Management Module**: Calibration logging, test parameter checks, standard equipment references, next calibration calculations, and status updates.
5. **Maintenance Management Module**: Work order ticketing, issue reporting, priority categorization, and resolution tracking.
6. **Dashboard Module**: Real-time aggregation of inventory counts, operational statuses, calibration due dates, and maintenance workload.
7. **Reports Module**: Standardized printable equipment calibration sheets utilizing native browser print (`window.print()`).
8. **Search & Filtering Module**: Multi-criteria searching (device ID, name, manufacturer) and filtering by clinical category and status.
9. **Role-Based Authorization Module**: Endpoint protection and UI view gating based on authenticated user roles (`ADMIN`, `TECHNICIAN`, `STAFF`).
10. **Date-Derived Status Alerts**: Automatic calculation of calibration urgency (Operational, Upcoming within 15 days, Overdue) based on comparison of `nextCalibrationDate` with system date.

---

## 6. Planned Folder Architecture

```
Biomedical-Calibration-System/
├── client/                     # Frontend Application (React + Vite + Plain CSS)
│   ├── public/                 # Static assets
│   ├── src/
│   │   ├── assets/             # Brand logos & icons
│   │   ├── components/         # Reusable UI elements (Navbar, Badges, Modals)
│   │   ├── context/            # Authentication Context API
│   │   ├── pages/              # View pages (Login, Dashboard, Equipment, Calibration)
│   │   ├── services/           # Native fetch() API integration methods
│   │   ├── styles/             # Plain CSS stylesheets (global and component-specific)
│   │   ├── App.jsx             # Root routing and route protection
│   │   ├── main.jsx            # React DOM mounting
│   │   └── index.css           # Global typography, color variables, print media rules
│   ├── index.html              # HTML entry point
│   ├── package.json            # Frontend dependency manifest
│   └── vite.config.js          # Vite development configuration
│
├── server/                     # Backend Application (Node.js + Express.js + Mongoose)
│   ├── config/                 # Database connection (db.js)
│   ├── controllers/            # Request handlers (auth, equipment, calibration, maintenance)
│   ├── middleware/             # Auth JWT verification and Role authorization guards
│   ├── models/                 # Mongoose schemas (User, Equipment, Calibration, Maintenance)
│   ├── routes/                 # Express REST endpoint routers
│   ├── seed/                   # Realistic biomedical equipment & calibration test seeders
│   ├── .env.example            # Environment variables template
│   ├── package.json            # Backend dependency manifest
│   └── server.js               # Application entry point and middleware configuration
│
├── docs/                       # Project Documentation & Blueprints
│   ├── PROJECT_SPEC.md         # Full project specification & boundaries
│   ├── DATABASE.md             # Mongoose schemas, relationships & status logic
│   ├── API_SPEC.md             # Complete REST API endpoint documentation
│   ├── ROLES.md                # Role-based access control matrix & workflows
│   ├── BUILD_LOG.md            # Chronological engineering decision log
│   └── IMPLEMENTATION_STATUS.md# Phase tracker and current progress breakdown
│
├── diagrams/                   # Architecture, ER, and sequence diagrams
├── screenshots/                # Application execution & Postman testing captures
├── .gitignore                  # Git ignore rules for node_modules, .env, and dist
└── README.md                   # Primary repository documentation
```

---

## 7. System Architecture Workflow

```
+-------------------------------------------------------------+
|                       Web Browser                           |
|       React.js UI Components  +  Plain CSS Stylesheets      |
+-------------------------------------------------------------+
                              │
                    Native browser fetch()
                     JSON Request Payload
                              │
                              ▼
+-------------------------------------------------------------+
|                     Express.js REST API                     |
|  - CORS & JSON Body Parser                                   |
|  - JWT Authentication Middleware (`authMiddleware.js`)      |
|  - Role Authorization Middleware (`roleMiddleware.js`)      |
+-------------------------------------------------------------+
                              │
                              ▼
+-------------------------------------------------------------+
|                   Business Logic Controllers                |
|  - Auth Controller (Login, Register, Profile)               |
|  - Equipment Controller (CRUD, Search, Filter)              |
|  - Calibration Controller (Log creation, Status sync)       |
|  - Maintenance Controller (Work orders, status updates)     |
|  - Dashboard Controller (Database count aggregations)       |
+-------------------------------------------------------------+
                              │
                              ▼
+-------------------------------------------------------------+
|                   Mongoose Schema Models                    |
|             User | Equipment | Calibration | Maintenance     |
+-------------------------------------------------------------+
                              │
                              ▼
+-------------------------------------------------------------+
|                      MongoDB Database                       |
|           biomedical_calibration_db Collections             |
+-------------------------------------------------------------+
```
