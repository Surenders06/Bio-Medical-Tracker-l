# Biomedical Device Calibration and Maintenance Management System

> **B.Tech Engineering Project**  
> *A web-based record management and tracking system for hospital biomedical equipment calibration schedules and maintenance records.*

---

## 1. Problem Statement
> *"Hospitals and laboratories must regularly calibrate biomedical devices and maintain maintenance records to comply with regulatory standards."*

Hospitals rely on a vast inventory of critical biomedical equipment—such as ECG machines, patient monitors, ICU ventilators, defibrillators, and infusion pumps. Ensuring measurement accuracy, patient safety, and regulatory compliance requires timely calibration and traceable maintenance logs.

This application provides a **centralized digital tracking system** to replace unreliable paper logbooks with automated date-derived status alerts, structured calibration logs, and role-based access.

---

## 2. Important System Definition & Boundaries

### What the System IS:
* A **record-management and tracking platform**.
* A tool to log calibration events, monitor upcoming due dates, and track maintenance work orders.

### What the System IS NOT (Mandatory Clarification):
* The software **does NOT** perform physical calibration of medical devices.
* The software **does NOT** certify medical equipment or issue regulatory compliance certificates.
* The software must **never claim** that it physically calibrates or certifies any medical equipment.
* All physical measurements and calibration adjustments are executed by trained clinical engineers using certified hardware calibration instruments (e.g., Fluke Biomedical simulators, Rigel analyzers). The system strictly records the resultant data.

---

## 3. Technology Stack Restrictions

This project strictly adheres to the approved technology stack to maintain academic standards:

| Layer | Approved Technology | Prohibited Alternatives |
|---|---|---|
| **Frontend** | React.js, Vite, React Router, Native browser `fetch()`, Plain CSS | Redux, Axios, Tailwind, Bootstrap, Recharts, Icon libraries |
| **Backend** | Node.js, Express.js, MongoDB, Mongoose, JWT, bcryptjs, dotenv, cors | Heavy ORMs, external auth providers, Nodemailer |
| **Watch Mode** | Native `node --watch` | External nodemon where appropriate |
| **Testing** | Postman | Unnecessary testing frameworks |
| **Reporting** | Browser native print (`window.print()`) + CSS `@media print` | PDF generation libraries, cloud storage, canvas tools |

---

## 4. Repository Structure

```
Biomedical-Calibration-System/
├── client/                     # Frontend Application (React + Vite + Plain CSS)
├── server/                     # Backend Application (Node.js + Express + Mongoose)
├── docs/                       # Project Documentation & Architecture Blueprints
│   ├── PROJECT_SPEC.md         # Full project scope, boundaries & module definitions
│   ├── DATABASE.md             # MongoDB schemas, Mongoose models & status rules
│   ├── API_SPEC.md             # REST API endpoint contracts and payloads
│   ├── ROLES.md                # Role-Based Access Control matrix & workflows
│   ├── BUILD_LOG.md            # Engineering decisions and architectural log
│   └── IMPLEMENTATION_STATUS.md# Module status and milestone tracking
├── diagrams/                   # Architecture, ER, and sequence diagrams
├── screenshots/                # Application execution & testing captures
├── .gitignore                  # Git ignore definitions
└── README.md                   # Project overview & navigation guide
```

---

## 5. User Roles & Authorization

The system defines three core roles:

1. **ADMIN (Head of Biomedical Engineering)**: Full administrative authority over user accounts, equipment registration, editing, and asset decommissioning.
2. **TECHNICIAN (Biomedical Service Technician)**: Logs calibration test parameters, updates operational device statuses, and resolves maintenance tickets.
3. **STAFF (ICU Nurse In-Charge / Clinical Staff)**: Frontline clinical staff with read-only verification rights to confirm equipment calibration validity before patient application, and ability to submit maintenance breakdown requests.

---

## 6. Core Modules

1. **Authentication**: Secure login with bcryptjs password hashing and stateless JWT tokens.
2. **User Management**: User administration and directory for Admin role.
3. **Biomedical Equipment Management**: Lifecycle management (ID, name, category, location, cost, status).
4. **Calibration Management**: Logging test results, standards used, next due dates, and equipment synchronization.
5. **Maintenance Management**: Work orders, priority levels, and resolution tracking.
6. **Dashboard**: Real-time database aggregations (Total inventory, Operational, Due, Out of Service).
7. **Reports**: Printable calibration reports using native browser print (`window.print()`).
8. **Search & Filtering**: Search across ID, name, manufacturer, and filter by clinical category/status.
9. **Role-Based Authorization**: Route guards and endpoint security.
10. **Date-Derived Status Alerts**: Automated flagging for `Calibration Due` (overdue) and upcoming warnings (within 15 days).

---

## 7. Development Phases

* **Phase 0 (Current)**: Architecture Blueprint, Documentation & Project Governance (**COMPLETED**)
* **Phase 1 (Next)**: Backend Database Models, MongoDB Connection & Seed Fixtures
* **Phase 2**: Express REST Controllers, Middleware & Postman Testing Suite
* **Phase 3**: React Frontend Scaffolding, Context API & Route Setup
* **Phase 4**: Biomedical Equipment & Calibration Interactive Modules (**50% College Review Target**)
* **Phase 5**: Maintenance Lifecycle, Browser Print Reports & Final Packaging

---

## 8. Current Status

* **Milestone**: Phase 0 Complete (Blueprint & Architecture)
* **Application Code**: Intentionally not built in this phase.
* **Next Action**: Awaiting instruction to begin Phase 1 (Backend Foundation).
