const mongoose = require('mongoose');

const calibrationSchema = new mongoose.Schema(
  {
    calibrationId: {
      type: String,
      required: [true, 'Calibration record ID is required'],
      unique: true,
      trim: true,
      uppercase: true
    },
    equipment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Equipment',
      required: [true, 'Associated equipment reference is required']
    },
    calibrationDate: {
      type: Date,
      required: [true, 'Calibration date is required'],
      default: Date.now
    },
    nextCalibrationDate: {
      type: Date,
      required: [true, 'Next calibration due date is required']
    },
    calibratedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Calibrating technician reference is required']
    },
    technicianName: {
      type: String,
      required: [true, 'Technician name is required'],
      trim: true
    },
    calibrationStandard: {
      type: String,
      default: 'Standard Biomedical Calibrator / Analyzer',
      trim: true
    },
    result: {
      type: String,
      enum: ['Passed', 'Passed with Adjustment', 'Failed', 'Needs Attention'],
      required: true,
      default: 'Passed'
    },
    parametersChecked: [
      {
        parameter: { type: String, trim: true },
        referenceValue: { type: String, trim: true },
        measuredValue: { type: String, trim: true },
        status: { type: String, enum: ['Pass', 'Fail', 'Adjusted'], default: 'Pass' }
      }
    ],
    remarks: {
      type: String,
      trim: true,
      default: 'Routine calibration check completed as per hospital protocol.'
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model('Calibration', calibrationSchema);
