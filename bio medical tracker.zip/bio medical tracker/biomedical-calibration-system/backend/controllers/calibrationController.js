const Calibration = require('../models/Calibration');
const Equipment = require('../models/Equipment');

/**
 * @desc    Get all calibration records with populated equipment and technician
 * @route   GET /api/calibrations
 * @access  Private (Admin, Technician, Staff)
 */
const getCalibrations = async (req, res) => {
  try {
    const { equipmentId, result } = req.query;
    const filter = {};

    if (equipmentId) {
      filter.equipment = equipmentId;
    }
    if (result && result !== 'All') {
      filter.result = result;
    }

    const calibrations = await Calibration.find(filter)
      .populate('equipment', 'equipmentId name category location status')
      .populate('calibratedBy', 'name email role')
      .sort({ calibrationDate: -1 });

    return res.status(200).json({
      success: true,
      count: calibrations.length,
      data: calibrations
    });
  } catch (error) {
    console.error('[Get Calibrations Error]:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve calibration logs',
      error: error.message
    });
  }
};

/**
 * @desc    Get single calibration record by ID
 * @route   GET /api/calibrations/:id
 * @access  Private (Admin, Technician, Staff)
 */
const getCalibrationById = async (req, res) => {
  try {
    const calibration = await Calibration.findById(req.params.id)
      .populate('equipment')
      .populate('calibratedBy', 'name email role department');

    if (!calibration) {
      return res.status(404).json({
        success: false,
        message: 'Calibration record not found'
      });
    }

    return res.status(200).json({
      success: true,
      data: calibration
    });
  } catch (error) {
    console.error('[Get Calibration By ID Error]:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve calibration record',
      error: error.message
    });
  }
};

/**
 * @desc    Create new calibration record and update equipment calibration status
 * @route   POST /api/calibrations
 * @access  Private (Admin, Technician)
 */
const createCalibration = async (req, res) => {
  try {
    const {
      calibrationId,
      equipmentId,
      calibrationDate,
      nextCalibrationDate,
      calibrationStandard,
      result,
      parametersChecked,
      remarks
    } = req.body;

    if (!calibrationId || !equipmentId || !nextCalibrationDate || !result) {
      return res.status(400).json({
        success: false,
        message: 'Please provide calibration ID, equipment, next calibration date, and test result.'
      });
    }

    // Verify equipment exists
    const equipment = await Equipment.findById(equipmentId);
    if (!equipment) {
      return res.status(404).json({
        success: false,
        message: 'Target biomedical equipment not found in database.'
      });
    }

    // Check unique calibration record ID
    const existing = await Calibration.findOne({ calibrationId: calibrationId.toUpperCase().trim() });
    if (existing) {
      return res.status(400).json({
        success: false,
        message: `Calibration certificate ID '${calibrationId}' has already been registered.`
      });
    }

    const calDate = calibrationDate ? new Date(calibrationDate) : new Date();
    const nextCalDate = new Date(nextCalibrationDate);

    // Create record
    const calibration = await Calibration.create({
      calibrationId: calibrationId.toUpperCase().trim(),
      equipment: equipment._id,
      calibrationDate: calDate,
      nextCalibrationDate: nextCalDate,
      calibratedBy: req.user._id,
      technicianName: req.user.name,
      calibrationStandard: calibrationStandard || 'Standard Biomedical Calibrator',
      result,
      parametersChecked: Array.isArray(parametersChecked) ? parametersChecked : [],
      remarks: remarks || 'Calibration completed and verified against standard.'
    });

    // Update equipment's calibration dates and operational status
    equipment.lastCalibrationDate = calDate;
    equipment.nextCalibrationDate = nextCalDate;

    if (result === 'Passed' || result === 'Passed with Adjustment') {
      equipment.status = 'Operational';
    } else if (result === 'Failed') {
      equipment.status = 'Out of Service';
    } else if (result === 'Needs Attention') {
      equipment.status = 'Maintenance Required';
    }

    await equipment.save();

    return res.status(201).json({
      success: true,
      message: 'Calibration record successfully saved and equipment status updated',
      data: calibration
    });
  } catch (error) {
    console.error('[Create Calibration Error]:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to save calibration record',
      error: error.message
    });
  }
};

module.exports = {
  getCalibrations,
  getCalibrationById,
  createCalibration
};
