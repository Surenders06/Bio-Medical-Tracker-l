const express = require('express');
const router = express.Router();
const { getDashboardSummary } = require('../controllers/dashboardController');
const { protect } = require('../middleware/authMiddleware');

// Dashboard statistics computed from live database
router.get('/summary', protect, getDashboardSummary);

module.exports = router;
