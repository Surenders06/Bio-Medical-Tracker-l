const express = require('express');
const router = express.Router();
const {
  login,
  register,
  getMe,
  getUsers
} = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');

// Public route: Login
router.post('/login', login);

// Registration: Open for seed or Admin
router.post('/register', register);

// Protected route: Current user profile
router.get('/me', protect, getMe);

// Admin only: List all registered users
router.get('/users', protect, authorize('Admin'), getUsers);

module.exports = router;
