const express = require('express');
const router = express.Router();
const {
  getCalibrations,
  getCalibrationById,
  createCalibration
} = require('../controllers/calibrationController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');

// All calibration routes require authentication
router.use(protect);

// View calibration records (Admin, Technician, Staff)
router.get('/', getCalibrations);

// View single calibration record details (Admin, Technician, Staff)
router.get('/:id', getCalibrationById);

// Record new calibration (Admin, Technician)
router.post('/', authorize('Admin', 'Technician'), createCalibration);

module.exports = router;
