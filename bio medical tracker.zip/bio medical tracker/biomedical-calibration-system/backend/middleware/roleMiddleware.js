/**
 * Role-Based Access Control Middleware
 * Restricts endpoint execution to specified user roles
 */
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'User authentication required prior to role verification.'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Role '${req.user.role}' is not authorized to perform this operation. Allowed roles: ${roles.join(', ')}`
      });
    }

    next();
  };
};

module.exports = { authorize };
